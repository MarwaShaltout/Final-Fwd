package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;
import org.example.Pages.P02_Login;

public class D02_LoginStepDefinition {
    WebDriver driver =Hooks.driver;
    P02_Login p_login=new P02_Login(driver);

    @Given("press on login button")
    public void login_button()
    {
       driver.findElement(By.xpath("//a[@class=\"ico-login\"]")).click();
    }

    @When("enter the already registered and valid email and password")
    public void enter_valid_data(String email,String password)
    {
      p_login.login_steps(email,password);
    }
    @And("press on login button")
    public void press_on_login_button()
    {
        driver.findElement(By.xpath("//div[@class=\"buttons\"]//button[@type=\"submit\"]")).click();

    }
    @Then("user log in successfully")
    public void successfully_login()
    {
        SoftAssert soft=new SoftAssert();
        soft.assertEquals("https://demo.nopcommerce.com/", driver.getCurrentUrl());
        String my_account=driver.findElement(By.xpath("//a[@class=\"ico-account\"]")).getText();
        soft.assertEquals(my_account,"my recently created account");
        soft.assertAll();
        System.out.println("my recently account");

    }

}

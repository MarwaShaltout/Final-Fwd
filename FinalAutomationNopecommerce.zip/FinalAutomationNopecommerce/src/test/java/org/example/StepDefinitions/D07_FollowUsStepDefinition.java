package org.example.StepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;

import java.util.ArrayList;


public class D07_FollowUsStepDefinition {

    WebDriver driver = Hooks.driver;
    ArrayList<String> Tabs = new ArrayList<>(Hooks.driver.getWindowHandles());

    @When("user press on the facebook link")
    public void press_on_facebook() {

        Hooks.driver.findElement(By.cssSelector("li[class=\"facebook\"]")).click();
    }

   @Then("the user is redirected to the facebook page in new tab")
    public void redirected_to_facebook_in_new_tab(String URL) throws InterruptedException {

       Thread.sleep(2000);
           Tabs = new ArrayList<>(driver.getWindowHandles());
           Hooks.driver.switchTo().window(Tabs.get(1));

           System.out.println(Hooks.driver.getCurrentUrl());
           System.out.println(Hooks.driver.getTitle());

       Assert.assertEquals(driver.getCurrentUrl(),"https://www.facebook.com/nopCommerce");

           driver.close();

         driver.switchTo().window(Tabs.get(0));
           System.out.println(driver.getCurrentUrl());

           driver.quit();

   }

@When("user press on twitter link")
    public void press_on_twitter()
{
    Hooks.driver.findElement(By.cssSelector("li[class=\"twitter\"]")).click();
}
@Then("the user is redirected to the twitter page in new tab")
    public void redirected_to_twitter_in_new_tab(String URL) throws InterruptedException {
    Thread.sleep(2000);
    Tabs = new ArrayList<>(driver.getWindowHandles());
    Hooks.driver.switchTo().window(Tabs.get(1));

    System.out.println(Hooks.driver.getCurrentUrl());
    System.out.println(Hooks.driver.getTitle());

    Assert.assertEquals(driver.getCurrentUrl(),"https://twitter.com/nopCommerce");

    driver.close();

    driver.switchTo().window(Tabs.get(0));
    System.out.println(driver.getCurrentUrl());

    driver.quit();

}
    @When("the user press on rss link")
    public void press_on_rss()
    {
        Hooks.driver.findElement(By.cssSelector("li[class=\"rss\"]")).click();
    }
    @Then("the user is redirected to the rss page in new tab")
    public void redirected_to_rss_in_new_tab(String URL) throws InterruptedException
    {
        Thread.sleep(3000);
        Tabs= new ArrayList<>(driver.getWindowHandles());
        Hooks.driver.switchTo().window(Tabs.get(1));

        System.out.println(Hooks.driver.getCurrentUrl());
        System.out.println(Hooks.driver.getTitle());

        Assert.assertEquals(driver.getCurrentUrl(),"https://demo.nopcommerce.com/new-online-store-is-open");

        driver.close();

        driver.switchTo().window(Tabs.get(0));
        System.out.println(driver.getCurrentUrl());
        driver.quit();
    }

    @When("user press on youtube link")
    public void press_on_youtube()
    {
        Hooks.driver.findElement(By.cssSelector("li[class=\"youtube\"]")).click();
    }
    @Then("the user is redirected to the youtube page in new tab")
    public void navigate_to_youtube_new_tab(String URL) throws InterruptedException
    {
        Thread.sleep(2000);
        Tabs = new ArrayList<>(driver.getWindowHandles());
        Hooks.driver.switchTo().window(Tabs.get(1));

        System.out.println(Hooks.driver.getCurrentUrl());
        System.out.println(Hooks.driver.getTitle());

        Assert.assertEquals(driver.getCurrentUrl(),"https://www.youtube.com/user/nopCommerce");
        driver.close();

        driver.switchTo().window(Tabs.get(0));
        System.out.println(driver.getCurrentUrl());
        driver.quit();


    }

}














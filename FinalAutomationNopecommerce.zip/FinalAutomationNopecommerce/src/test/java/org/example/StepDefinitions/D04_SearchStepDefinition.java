package org.example.StepDefinitions;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.testng.asserts.SoftAssert;

public class D04_SearchStepDefinition {
    WebDriver driver = Hooks.driver;

    public WebElement search_category() {
        By search=By.id("small-searchterms");
        return driver.findElement(search);
    }

@Given("user enter \"AP_MBP_13\" on search field")
    public void enetr_sku(String saerch_sku)
{
    search_category().sendKeys(saerch_sku);
    System.out.println("AP_MBP_13");
}
    @When("user press on search buttonn")
    public void click_on_Search_btton()
    {
        driver.findElement(By.xpath("//button[@type=\"submit\"]")).click();
    }
    @Then("user get search result with the product AP_MBP_13")
    public void electric_Category()
    {
        SoftAssert soft=new SoftAssert();
        String expectedresult="https://demo.nopcommerce.com/search?q=AP_MBP_13";
        String actualresult=Hooks.driver.getCurrentUrl();
        System.out.println(actualresult);
        soft.assertTrue(actualresult.contains(expectedresult),"true");
        int size=driver.findElements(By.id("q")).size();
        soft.assertTrue(size>0,"true");
        System.out.println("size>0");
        soft.assertAll();

    }

}
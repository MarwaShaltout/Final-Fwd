package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.asserts.SoftAssert;
import org.example.Pages.P01_Registration;

public class D01_RegistrationStepDefiniation {
    WebDriver driver =Hooks.driver;
    P01_Registration p_register = new P01_Registration(driver);



   @Given("press on register button")
    public void click_register_tab()
   {
       driver.findElement(By.linkText("Register")).click();
   }
   @When("user enter valid data")
    public void fill_data()
   {
       p_register.firstnamePOM().sendKeys("Marwa");
       p_register.lastnamePOM().sendKeys("Shaltout");
       p_register.email().sendKeys("marwa@gmail.com");
       p_register.day().click();
       p_register.month().click();
       p_register.year().click();
       p_register.company_name().sendKeys("Test Company");
       p_register.password().sendKeys("Test@123");
       p_register.password_confrm().sendKeys("Test@123");


   }
   @And("press on register button")
    public void press_on_register_button()
   {
       driver.findElement(By.id("register-button")).click();

   }

   @Then("user successfully registered")
    public void successfully_registered()
   {
       SoftAssert soft=new SoftAssert();
       String expectedResult="Congratulations, you are registered now!";
       String actualResult=driver.findElement(By.xpath("//div[@class=\"result\"]")).getText();
       soft.assertTrue(actualResult.contains(expectedResult),"gettext");
      String message_color=driver.findElement(By.xpath("//div[@class=\"result\"]")).getCssValue("color");
       soft.assertEquals(message_color,"rgba(76, 177, 124, 1)");
       soft.assertAll();

   }
   @And("user redirected to the home page")
    public void redirected_to_the_homepage()
   {
System.out.println("done");

   }
}

package org.example.StepDefinitions;

import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.example.Pages.P03_HomePage;

public class D06_HomeSlidersStepDefinition {
    WebDriver driver =Hooks.driver;
    P03_HomePage home=new P03_HomePage(driver);


@When("press on the first slider")
    public void click_on_first_slider()
{
    home.sliders("1").click();
}
@Then("navigate to Nokia Lumia 1020")
    public void nokia_page()
{

    Assert.assertTrue(Hooks.driver.getCurrentUrl().contains("https://demo.nopcommerce.com/nokia-lumia-1020"));
}
@When("press on second slider")
    public void click_on_second_slider()
{
    home.sliders("2");
}
@Then("navigate to iphone-6")
    public void iphone_page()
{
    Assert.assertTrue(Hooks.driver.getCurrentUrl().contains("https://demo.nopcommerce.com/iphone-6"));
}


}

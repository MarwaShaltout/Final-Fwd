package org.example.StepDefinitions;

import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.testng.Assert;
import org.example.Pages.P04_WishList;

public class D08_WishlistStepDefinition {

    int number;
    WebDriver driver =Hooks.driver;
    P04_WishList p04_wishList=new P04_WishList(driver);
    @When("user select the required products and add them to the wishlist")
    public void wish_list()
    {

        p04_wishList.wishlist().get(2).click();
        System.out.println("Successfully selected");

    }
    @Then("user gets a notification message that the products successfully added to the wish list")
    public void notification_success()
    {
        Assert.assertTrue(Hooks.driver.findElement(By.cssSelector("div[class=\"bar-notification success\"]")).isDisplayed());
    }

@And("number of wishlist items increased")
    public void wish_items_increase()
  {
    Assert.assertTrue(number > 0);
  }
}

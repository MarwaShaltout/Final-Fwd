package org.example.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P01_Registration {

    WebDriver driver;

    public P01_Registration(WebDriver driver){
        this.driver=driver;
    }

    public WebElement gender()
    {
        By female=By.id("gender-female");
        return driver.findElement(female);

    }
    public WebElement firstnamePOM()
    {
        By firstname=By.id("FirstName");
        return driver.findElement(firstname);

    }

    public WebElement lastnamePOM()
    {
        By lastname=By.id("LastName");
        return driver.findElement(lastname);

    }
    public WebElement email() {
        By email = By.id("Email");
        return driver.findElement(email);
    }
    public WebElement day()
    {
        By day=By.xpath("//select[@name=\"DateOfBirthDay\"]//option[@value=\"10\"]");
        return driver.findElement(day);
    }
    public WebElement month()
    {
        By month=By.xpath("//select[@name=\"DateOfBirthMonth\"] //option [@value=\"4\"]");
        return driver.findElement(month);
    }
    public WebElement year()
    {
        By year=By.xpath("//select[@name=\"DateOfBirthYear\"] //option [@value=\"1991\"]");
        return driver.findElement(year);
    }
    public WebElement company_name() {
        By com_name = By.id("Company");
        return driver.findElement(com_name);
    }

    public WebElement password()
    {
        By pass_word=By.id("Password");
        return driver.findElement(pass_word);
    }
    public WebElement password_confrm()
    {
        By pass_word_confrm=By.id("ConfirmPassword");
        return driver.findElement(pass_word_confrm);
    }

}

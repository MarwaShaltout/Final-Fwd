package org.example.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

public class P02_Login {

    WebDriver driver;
    public P02_Login(WebDriver driver){
        this.driver=driver;
    }

    public WebElement email()
    {
        By email=By.id("Email");
        return driver.findElement(email);
    }
    public WebElement password() {
        By password = By.id("Password");
        return driver.findElement(password);
    }
    public void login_steps(String email,String password)
    {
        email().clear();
        email().sendKeys(email);
       password().sendKeys(password);
    }


}

package org.example.Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.example.StepDefinitions.Hooks;

public class P03_HomePage {
    WebDriver driver;

    public P03_HomePage(WebDriver driver){
        this.driver=driver;

    }

        public WebElement sliders(String num)
        {
            return Hooks.driver.findElement(By.cssSelector("a[class=\"m-imageLink\"]:nth-child("+num+")"));

        }
    }



